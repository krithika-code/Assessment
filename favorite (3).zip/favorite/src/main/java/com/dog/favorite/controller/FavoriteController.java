package com.dog.favorite.controller;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.servlet.http.HttpServletRequest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FavoriteController {

	@RequestMapping("/")
	public String getDogs() {
		return "index";
	}

	@RequestMapping("/favorites")
	public String viewFavoriteDogs() {
		return "main";
	}

	@RequestMapping("/download/{fileName:.+}")
	public ResponseEntity<FileSystemResource> downloadFileAsEntity(
		      HttpServletRequest request, @PathVariable("fileName") String fileName) {
		    
		    String dir = request.getServletContext().getRealPath("/WEB-INF/downloads/");
		    
		    Path file = Paths.get(dir, fileName);
		    FileSystemResource fileResource = new FileSystemResource(file.toFile());
		    if(!Files.exists(file)){                     
		      return ResponseEntity.notFound().build();
		    }
		    String mimeType= request.getServletContext().getMimeType(
		      file.getFileName().toString());
		    if(mimeType==null){
		      mimeType = "application/octet-stream";
		    }
		    return ResponseEntity.ok()
		    .header("Content-Disposition", "attachment; filename="+fileName)
		    .contentType(MediaType.valueOf(mimeType)).body(fileResource);
		  }
}
