package com.webtracking.demo.controller;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
	private final Log logger = LogFactory.getLog(getClass());
	
	@GetMapping("/ping/{Dir}/{file}")
    public ResponseEntity<String> serviceBasic(@PathVariable String Dir, @PathVariable String file) {
		if(Dir.equals("tmp") && file.equals("ok")) {
		 return ResponseEntity.status(HttpStatus.OK).body("OK");
		} else {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("503 Service Unavailable");
		}
    }
	
	@RequestMapping(value = "/img", method = RequestMethod.GET, produces = MediaType.IMAGE_GIF_VALUE)
	public void getImage(HttpServletResponse response) throws IOException {
		logger.trace("LOG TRACE RESPONSE"+response);
		var imgFile = new ClassPathResource("image/img.gif");
   		response.setContentType(MediaType.IMAGE_GIF_VALUE);
   		StreamUtils.copy(imgFile.getInputStream(), response.getOutputStream());
   		logger.info("LOG TRACE INFO"+response);
	}
}
